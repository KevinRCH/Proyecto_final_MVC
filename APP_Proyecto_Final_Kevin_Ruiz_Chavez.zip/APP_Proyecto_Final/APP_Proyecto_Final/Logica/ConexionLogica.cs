﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace APP_Proyecto_Final.Logica
{
    public class ConexionLogica
    {
        public static string Cn = "Data Source=DESKTOP-48FE8MQ;Initial Catalog=DBBiblioteca_ProyectoFinal;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
    }
}
