﻿using APP_Proyecto_Final.Models;
using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace APP_Proyecto_Final.Logica
{
    public class login
    {
        private static login instancia = null;

        public login()
        {

        }

        public static login Instancia
        {
            get
            {
                if (instancia == null)
                {
                    instancia = new login();
                }

                return instancia;
            }
        }

        public List<TUsuario> Listar()
        {
            Console.WriteLine("Entro al listar");
            List<TUsuario> Lista = new List<TUsuario>();
            Console.WriteLine("Entro al listar");
            using (SqlConnection oConexion = new SqlConnection(ConexionLogica.Cn))
            {
                try
                {
                    StringBuilder sb = new StringBuilder();
                    sb.AppendLine("select p.ID_persona,p.Nombre,p.Apellidos,p.Correo,p.Clave,p.Codigo,tp.ID_Tipopersona,tp.Descripcion, p.Estado from [T_USUARIOS] p");
                    sb.AppendLine("inner join [T_TIPOPERSONA] tp on tp.ID_Tipopersona = p.Id_Tipopersona");

                    SqlCommand cmd = new SqlCommand(sb.ToString(), oConexion);
                    cmd.CommandType = CommandType.Text;

                    oConexion.Open();
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            Lista.Add(new TUsuario()
                            {
                                IdPersona = Convert.ToInt32(dr["ID_persona"]),
                                Nombre = dr["Nombre"].ToString(),
                                Apellidos = dr["Apellidos"].ToString(),
                                Correo = dr["Correo"].ToString(),
                                Clave = dr["Clave"].ToString(),
                                Codigo = dr["Codigo"].ToString(),
                                IdTipopersona = Convert.ToInt32(dr["ID_Tipopersona"]),
                                Estado = Convert.ToBoolean(dr["Estado"])
                            });
                        }
                    }

                }
                catch (Exception ex)
                {
                    Lista = new List<TUsuario>();
                }
            }
            return Lista;
        }
    }
}
