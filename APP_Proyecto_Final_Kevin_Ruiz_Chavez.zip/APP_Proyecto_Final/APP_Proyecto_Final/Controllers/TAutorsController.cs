﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using APP_Proyecto_Final.Models;

namespace APP_Proyecto_Final.Controllers
{
    public class TAutorsController : Controller
    {
        private readonly DBBiblioteca_ProyectoFinalContext _context;

        public TAutorsController(DBBiblioteca_ProyectoFinalContext context)
        {
            _context = context;
        }

        // GET: TAutors
        public async Task<IActionResult> Index()
        {
            return View(await _context.TAutors.ToListAsync());
        }

        // GET: TAutors/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var tAutor = await _context.TAutors
                .FirstOrDefaultAsync(m => m.IdAutor == id);
            if (tAutor == null)
            {
                return NotFound();
            }

            return View(tAutor);
        }

        // GET: TAutors/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: TAutors/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("IdAutor,NombreApellidos,Estado,FechaCreacion")] TAutor tAutor)
        {
            if (ModelState.IsValid)
            {
                _context.Add(tAutor);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(tAutor);
        }

        // GET: TAutors/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var tAutor = await _context.TAutors.FindAsync(id);
            if (tAutor == null)
            {
                return NotFound();
            }
            return View(tAutor);
        }

        // POST: TAutors/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("IdAutor,NombreApellidos,Estado,FechaCreacion")] TAutor tAutor)
        {
            if (id != tAutor.IdAutor)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(tAutor);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!TAutorExists(tAutor.IdAutor))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(tAutor);
        }

        // GET: TAutors/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var tAutor = await _context.TAutors
                .FirstOrDefaultAsync(m => m.IdAutor == id);
            if (tAutor == null)
            {
                return NotFound();
            }

            return View(tAutor);
        }

        // POST: TAutors/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var tAutor = await _context.TAutors.FindAsync(id);
            _context.TAutors.Remove(tAutor);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool TAutorExists(int id)
        {
            return _context.TAutors.Any(e => e.IdAutor == id);
        }
    }
}
