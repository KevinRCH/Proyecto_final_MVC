﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using APP_Proyecto_Final.Models;

namespace APP_Proyecto_Final.Controllers
{
    public class TCategoriaLibroesController : Controller
    {
        private readonly DBBiblioteca_ProyectoFinalContext _context;

        public TCategoriaLibroesController(DBBiblioteca_ProyectoFinalContext context)
        {
            _context = context;
        }

        // GET: TCategoriaLibroes
        public async Task<IActionResult> Index()
        {
            return View(await _context.TCategoriaLibros.ToListAsync());
        }

        // GET: TCategoriaLibroes/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var tCategoriaLibro = await _context.TCategoriaLibros
                .FirstOrDefaultAsync(m => m.IdCategoria == id);
            if (tCategoriaLibro == null)
            {
                return NotFound();
            }

            return View(tCategoriaLibro);
        }

        // GET: TCategoriaLibroes/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: TCategoriaLibroes/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("IdCategoria,Nombre,Estado,FechaCreacion")] TCategoriaLibro tCategoriaLibro)
        {
            if (ModelState.IsValid)
            {
                _context.Add(tCategoriaLibro);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(tCategoriaLibro);
        }

        // GET: TCategoriaLibroes/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var tCategoriaLibro = await _context.TCategoriaLibros.FindAsync(id);
            if (tCategoriaLibro == null)
            {
                return NotFound();
            }
            return View(tCategoriaLibro);
        }

        // POST: TCategoriaLibroes/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("IdCategoria,Nombre,Estado,FechaCreacion")] TCategoriaLibro tCategoriaLibro)
        {
            if (id != tCategoriaLibro.IdCategoria)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(tCategoriaLibro);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!TCategoriaLibroExists(tCategoriaLibro.IdCategoria))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(tCategoriaLibro);
        }

        // GET: TCategoriaLibroes/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var tCategoriaLibro = await _context.TCategoriaLibros
                .FirstOrDefaultAsync(m => m.IdCategoria == id);
            if (tCategoriaLibro == null)
            {
                return NotFound();
            }

            return View(tCategoriaLibro);
        }

        // POST: TCategoriaLibroes/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var tCategoriaLibro = await _context.TCategoriaLibros.FindAsync(id);
            _context.TCategoriaLibros.Remove(tCategoriaLibro);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool TCategoriaLibroExists(int id)
        {
            return _context.TCategoriaLibros.Any(e => e.IdCategoria == id);
        }
    }
}
