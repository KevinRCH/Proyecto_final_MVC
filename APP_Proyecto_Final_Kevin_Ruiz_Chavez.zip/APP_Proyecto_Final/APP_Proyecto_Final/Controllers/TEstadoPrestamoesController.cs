﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using APP_Proyecto_Final.Models;
using Microsoft.Data.SqlClient;
using APP_Proyecto_Final.Logica;
using System.Data;

namespace APP_Proyecto_Final.Controllers
{
    public class TEstadoPrestamoesController : Controller
    {
        private readonly DBBiblioteca_ProyectoFinalContext _context;

        public TEstadoPrestamoesController(DBBiblioteca_ProyectoFinalContext context)
        {
            _context = context;
        }

        // GET: TEstadoPrestamoes
        public async Task<IActionResult> Index()
        {
            return View(await _context.TEstadoPrestamos.ToListAsync());
        }

        // GET: TEstadoPrestamoes/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var tEstadoPrestamo = await _context.TEstadoPrestamos
                .FirstOrDefaultAsync(m => m.IdEstado == id);
            if (tEstadoPrestamo == null)
            {
                return NotFound();
            }

            return View(tEstadoPrestamo);
        }

        // GET: TEstadoPrestamoes/Create
        public IActionResult Create()
        {
            return View();
        }
        public IActionResult Devolucion()
        {
            return View();
        }

            // POST: TEstadoPrestamoes/Create
            // To protect from overposting attacks, enable the specific properties you want to bind to.
            // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.

            public async Task<IActionResult> Create([Bind("IdEstado,Descripcion,Estado,FechaCreacion")] TEstadoPrestamo tEstadoPrestamo)
        {
            if (ModelState.IsValid)
            {
                _context.Add(tEstadoPrestamo);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(tEstadoPrestamo);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Devoluciones(int idpersona, string codigo,int idprestamo, string estado)
        {
            
            using (var conexion = new SqlConnection(ConexionLogica.Cn))
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "sp_Devolucion_Prestamo";
                cmd.Parameters.Add("@ID_persona", SqlDbType.Int).Value = idpersona;
                cmd.Parameters.Add("@Codigo", SqlDbType.VarChar).Value = codigo;
                cmd.Parameters.Add("@ID_Prestamo", SqlDbType.Int).Value = idprestamo;
                cmd.Parameters.Add("@Estado_Recibido", SqlDbType.VarChar).Value = estado;
                cmd.Connection = conexion;
                conexion.Open();
                cmd.ExecuteNonQuery();

            }
            return RedirectToAction("Index", "TEstadoController");
            //return View(tPrestamo);
        }
        // GET: TEstadoPrestamoes/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var tEstadoPrestamo = await _context.TEstadoPrestamos.FindAsync(id);
            if (tEstadoPrestamo == null)
            {
                return NotFound();
            }
            return View(tEstadoPrestamo);
        }

        // POST: TEstadoPrestamoes/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("IdEstado,Descripcion,Estado,FechaCreacion")] TEstadoPrestamo tEstadoPrestamo)
        {
            if (id != tEstadoPrestamo.IdEstado)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(tEstadoPrestamo);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!TEstadoPrestamoExists(tEstadoPrestamo.IdEstado))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(tEstadoPrestamo);
        }

        // GET: TEstadoPrestamoes/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var tEstadoPrestamo = await _context.TEstadoPrestamos
                .FirstOrDefaultAsync(m => m.IdEstado == id);
            if (tEstadoPrestamo == null)
            {
                return NotFound();
            }

            return View(tEstadoPrestamo);
        }

        // POST: TEstadoPrestamoes/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var tEstadoPrestamo = await _context.TEstadoPrestamos.FindAsync(id);
            _context.TEstadoPrestamos.Remove(tEstadoPrestamo);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool TEstadoPrestamoExists(int id)
        {
            return _context.TEstadoPrestamos.Any(e => e.IdEstado == id);
        }
    }
}
