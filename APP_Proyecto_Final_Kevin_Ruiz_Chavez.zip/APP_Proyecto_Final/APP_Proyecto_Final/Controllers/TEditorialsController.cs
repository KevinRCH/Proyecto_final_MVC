﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using APP_Proyecto_Final.Models;

namespace APP_Proyecto_Final.Controllers
{
    public class TEditorialsController : Controller
    {
        private readonly DBBiblioteca_ProyectoFinalContext _context;

        public TEditorialsController(DBBiblioteca_ProyectoFinalContext context)
        {
            _context = context;
        }

        // GET: TEditorials
        public async Task<IActionResult> Index()
        {
            return View(await _context.TEditorials.ToListAsync());
        }

        // GET: TEditorials/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var tEditorial = await _context.TEditorials
                .FirstOrDefaultAsync(m => m.IdEditorial == id);
            if (tEditorial == null)
            {
                return NotFound();
            }

            return View(tEditorial);
        }

        // GET: TEditorials/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: TEditorials/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("IdEditorial,Nombre,Correo,Pais,Estado,FechaCreacion")] TEditorial tEditorial)
        {
            if (ModelState.IsValid)
            {
                _context.Add(tEditorial);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(tEditorial);
        }

        // GET: TEditorials/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var tEditorial = await _context.TEditorials.FindAsync(id);
            if (tEditorial == null)
            {
                return NotFound();
            }
            return View(tEditorial);
        }

        // POST: TEditorials/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("IdEditorial,Nombre,Correo,Pais,Estado,FechaCreacion")] TEditorial tEditorial)
        {
            if (id != tEditorial.IdEditorial)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(tEditorial);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!TEditorialExists(tEditorial.IdEditorial))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(tEditorial);
        }

        // GET: TEditorials/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var tEditorial = await _context.TEditorials
                .FirstOrDefaultAsync(m => m.IdEditorial == id);
            if (tEditorial == null)
            {
                return NotFound();
            }

            return View(tEditorial);
        }

        // POST: TEditorials/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var tEditorial = await _context.TEditorials.FindAsync(id);
            _context.TEditorials.Remove(tEditorial);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool TEditorialExists(int id)
        {
            return _context.TEditorials.Any(e => e.IdEditorial == id);
        }
    }
}
