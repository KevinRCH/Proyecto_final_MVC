﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using APP_Proyecto_Final.Models;
using Microsoft.Data.SqlClient;
using APP_Proyecto_Final.Logica;
using System.Data;
using System.Text;

namespace APP_Proyecto_Final.Controllers
{
    public class TPrestamoesController : Controller
    {
        private readonly DBBiblioteca_ProyectoFinalContext _context;

        public TPrestamoesController(DBBiblioteca_ProyectoFinalContext context)
        {
            _context = context;
        }

        // GET: TPrestamoes
        public async Task<IActionResult> Index()
        {
            var dBBiblioteca_ProyectoFinalContext = _context.TPrestamos.Include(t => t.IdEstadoPrestamoNavigation).Include(t => t.IdLibroNavigation).Include(t => t.IdPersonaNavigation);
            return View(await dBBiblioteca_ProyectoFinalContext.ToListAsync());
        }

        // GET: TPrestamoes/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var tPrestamo = await _context.TPrestamos
                .Include(t => t.IdEstadoPrestamoNavigation)
                .Include(t => t.IdLibroNavigation)
                .Include(t => t.IdPersonaNavigation)
                .FirstOrDefaultAsync(m => m.IdPrestamo == id);
            if (tPrestamo == null)
            {
                return NotFound();
            }

            return View(tPrestamo);
        }

        // GET: TPrestamoes/Create
        public IActionResult Create()
        {
            ViewData["IdEstadoPrestamo"] = new SelectList(_context.TEstadoPrestamos, "IdEstado", "IdEstado");
            ViewData["IdLibro"] = new SelectList(_context.TLibros, "IdLibro", "Titulo");
            ViewData["IdPersona"] = new SelectList(_context.TUsuarios, "IdPersona", "Apellidos");
            return View();
        }
        public IActionResult Devolver()
        {
            ViewData["IdEstadoPrestamo"] = new SelectList(_context.TEstadoPrestamos, "IdEstado", "IdEstado");
            ViewData["IdLibro"] = new SelectList(_context.TLibros, "IdLibro", "Titulo");
            ViewData["IdPersona"] = new SelectList(_context.TUsuarios, "IdPersona", "Apellidos");
            return View();
        }

        // POST: TPrestamoes/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("IdPrestamo,IdEstadoPrestamo,IdPersona,IdLibro,EstadoEntrega,EstadoRecibido,Estado")] TPrestamo tPrestamo)
        {
            /*if (ModelState.IsValid)
            {
                _context.Add(tPrestamo);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["IdEstadoPrestamo"] = new SelectList(_context.TEstadoPrestamos, "IdEstado", "IdEstado", tPrestamo.IdEstadoPrestamo);
            ViewData["IdLibro"] = new SelectList(_context.TLibros, "IdLibro", "Titulo", tPrestamo.IdLibro);
            ViewData["IdPersona"] = new SelectList(_context.TUsuarios, "IdPersona", "Apellidos", tPrestamo.IdPersona);
            */
            
            
                using (var conexion = new SqlConnection(ConexionLogica.Cn))
                {
                    SqlCommand cmd = new SqlCommand();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "sp_Registrar_Prestamo";
                    cmd.Parameters.Add("@Descripcion", SqlDbType.VarChar).Value = "Devolucion Pendiente";
                    cmd.Parameters.Add("@Estado2", SqlDbType.Bit).Value = 1;
                    cmd.Parameters.Add("@ID_Persona", SqlDbType.Int).Value = tPrestamo.IdPersona;
                    cmd.Parameters.Add("@ID_Libro", SqlDbType.Int).Value = tPrestamo.IdLibro;
                    cmd.Parameters.Add("@Estado_Entrega", SqlDbType.VarChar).Value = tPrestamo.EstadoEntrega;
                    cmd.Parameters.Add("@Estado", SqlDbType.Bit).Value = tPrestamo.Estado;
                    cmd.Connection = conexion;
                    conexion.Open();
                    cmd.ExecuteNonQuery();
                }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
            //return View(tPrestamo);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Devolver([Bind("IdPrestamo,IdEstadoPrestamo,IdPersona,IdLibro,EstadoEntrega,EstadoRecibido,Estado")] TPrestamo tPrestamo)
        {

            using (var conexion = new SqlConnection(ConexionLogica.Cn))
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "sp_Devolucion_Prestamo";
                cmd.Parameters.Add("@ID_persona", SqlDbType.Int).Value = 1;
                cmd.Parameters.Add("@Codigo", SqlDbType.VarChar).Value = 1;
                cmd.Parameters.Add("@ID_Prestamo", SqlDbType.Int).Value = 1;
                cmd.Parameters.Add("@Estado_Recibido", SqlDbType.VarChar).Value = 1;
                cmd.Connection = conexion;
                conexion.Open();
                cmd.ExecuteNonQuery();

            }
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
            //return View(tPrestamo);
        }
        // GET: TPrestamoes/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var tPrestamo = await _context.TPrestamos.FindAsync(id);
            if (tPrestamo == null)
            {
                return NotFound();
            }
            ViewData["IdEstadoPrestamo"] = new SelectList(_context.TEstadoPrestamos, "IdEstado", "IdEstado", tPrestamo.IdEstadoPrestamo);
            ViewData["IdLibro"] = new SelectList(_context.TLibros, "IdLibro", "Titulo", tPrestamo.IdLibro);
            ViewData["IdPersona"] = new SelectList(_context.TUsuarios, "IdPersona", "Apellidos", tPrestamo.IdPersona);
            return View(tPrestamo);
        }

        // POST: TPrestamoes/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("IdPrestamo,IdEstadoPrestamo,IdPersona,IdLibro,FechaDevolucion,FechaDevolucionReal,EstadoEntrega,EstadoRecibido,Estado,FechaCreacion")] TPrestamo tPrestamo)
        {
            if (id != tPrestamo.IdPrestamo)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(tPrestamo);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!TPrestamoExists(tPrestamo.IdPrestamo))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["IdEstadoPrestamo"] = new SelectList(_context.TEstadoPrestamos, "IdEstado", "IdEstado", tPrestamo.IdEstadoPrestamo);
            ViewData["IdLibro"] = new SelectList(_context.TLibros, "IdLibro", "Titulo", tPrestamo.IdLibro);
            ViewData["IdPersona"] = new SelectList(_context.TUsuarios, "IdPersona", "Apellidos", tPrestamo.IdPersona);
            return View(tPrestamo);
        }

        // GET: TPrestamoes/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var tPrestamo = await _context.TPrestamos
                .Include(t => t.IdEstadoPrestamoNavigation)
                .Include(t => t.IdLibroNavigation)
                .Include(t => t.IdPersonaNavigation)
                .FirstOrDefaultAsync(m => m.IdPrestamo == id);
            if (tPrestamo == null)
            {
                return NotFound();
            }

            return View(tPrestamo);
        }

        // POST: TPrestamoes/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var tPrestamo = await _context.TPrestamos.FindAsync(id);
            _context.TPrestamos.Remove(tPrestamo);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool TPrestamoExists(int id)
        {
            return _context.TPrestamos.Any(e => e.IdPrestamo == id);
        }
    }
}
