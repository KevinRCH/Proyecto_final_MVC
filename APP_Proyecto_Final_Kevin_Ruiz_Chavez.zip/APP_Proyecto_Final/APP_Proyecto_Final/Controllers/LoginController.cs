﻿using APP_Proyecto_Final.Logica;
using APP_Proyecto_Final.Models;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace APP_Proyecto_Final.Controllers
{
    public class LoginController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> Index(string correo, string clave)
        {

            TUsuario ousuario = login.Instancia.Listar().Where(u => u.Correo == correo && u.Clave == clave).FirstOrDefault();

            if (ousuario == null)
            {
                ViewBag.Error = "Usuario o contraseña no correcta";
                return View();
            }
            else
            {
                if (ousuario.IdTipopersona == 1 || ousuario.IdTipopersona == 2)
                {
                    var clains = new List<Claim>
                    {
                        new Claim(ClaimTypes.Name,ousuario.Nombre+" "+ousuario.Apellidos),
                        new Claim("Correo",ousuario.Correo),
                        new Claim(ClaimTypes.Role, ousuario.IdTipopersona.ToString())
                    };
                    var clainsIdentity = new ClaimsIdentity(clains, CookieAuthenticationDefaults.AuthenticationScheme);
                    await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, new ClaimsPrincipal(clainsIdentity));
                    return RedirectToAction("Index", "Home");
                }
                else
                {

                    ViewBag.Error = "Acceso denegado";
                    return RedirectToAction("Index", "Login");
                }

            }

        }
        public async Task<IActionResult> Salir()
        {
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);

            return RedirectToAction("Index", "Login");
        }
    }
}
