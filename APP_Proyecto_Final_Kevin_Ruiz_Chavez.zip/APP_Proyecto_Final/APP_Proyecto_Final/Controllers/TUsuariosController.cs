﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using APP_Proyecto_Final.Models;

namespace APP_Proyecto_Final.Controllers
{
    public class TUsuariosController : Controller
    {
        private readonly DBBiblioteca_ProyectoFinalContext _context;

        public TUsuariosController(DBBiblioteca_ProyectoFinalContext context)
        {
            _context = context;
        }

        // GET: TUsuarios
        public async Task<IActionResult> Index()
        {
            var dBBiblioteca_ProyectoFinalContext = _context.TUsuarios.Include(t => t.IdTipopersonaNavigation);
            return View(await dBBiblioteca_ProyectoFinalContext.ToListAsync());
        }

        // GET: TUsuarios/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var tUsuario = await _context.TUsuarios
                .Include(t => t.IdTipopersonaNavigation)
                .FirstOrDefaultAsync(m => m.IdPersona == id);
            if (tUsuario == null)
            {
                return NotFound();
            }

            return View(tUsuario);
        }

        // GET: TUsuarios/Create
        public IActionResult Create()
        {
            ViewData["IdTipopersona"] = new SelectList(_context.TTipopersonas, "IdTipoPersona", "Descripcion");
            return View();
        }

        // POST: TUsuarios/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("IdPersona,Nombre,Apellidos,Correo,Clave,Codigo,IdTipopersona,Estado,FechaCreacion")] TUsuario tUsuario)
        {
            if (ModelState.IsValid)
            {
                _context.Add(tUsuario);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["IdTipopersona"] = new SelectList(_context.TTipopersonas, "IdTipoPersona", "Descripcion", tUsuario.IdTipopersona);
            return View(tUsuario);
        }

        // GET: TUsuarios/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var tUsuario = await _context.TUsuarios.FindAsync(id);
            if (tUsuario == null)
            {
                return NotFound();
            }
            ViewData["IdTipopersona"] = new SelectList(_context.TTipopersonas, "IdTipoPersona", "Descripcion", tUsuario.IdTipopersona);
            return View(tUsuario);
        }

        // POST: TUsuarios/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("IdPersona,Nombre,Apellidos,Correo,Clave,Codigo,IdTipopersona,Estado,FechaCreacion")] TUsuario tUsuario)
        {
            if (id != tUsuario.IdPersona)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(tUsuario);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!TUsuarioExists(tUsuario.IdPersona))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["IdTipopersona"] = new SelectList(_context.TTipopersonas, "IdTipoPersona", "Descripcion", tUsuario.IdTipopersona);
            return View(tUsuario);
        }

        // GET: TUsuarios/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var tUsuario = await _context.TUsuarios
                .Include(t => t.IdTipopersonaNavigation)
                .FirstOrDefaultAsync(m => m.IdPersona == id);
            if (tUsuario == null)
            {
                return NotFound();
            }

            return View(tUsuario);
        }

        // POST: TUsuarios/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var tUsuario = await _context.TUsuarios.FindAsync(id);
            _context.TUsuarios.Remove(tUsuario);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool TUsuarioExists(int id)
        {
            return _context.TUsuarios.Any(e => e.IdPersona == id);
        }
    }
}
