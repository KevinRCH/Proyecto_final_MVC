﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using APP_Proyecto_Final.Models;

namespace APP_Proyecto_Final.Controllers
{
    public class TLibroesController : Controller
    {
        private readonly DBBiblioteca_ProyectoFinalContext _context;

        public TLibroesController(DBBiblioteca_ProyectoFinalContext context)
        {
            _context = context;
        }

        // GET: TLibroes
        public async Task<IActionResult> Index()
        {
            var dBBiblioteca_ProyectoFinalContext = _context.TLibros.Include(t => t.IdAutorNavigation).Include(t => t.IdCategoriaNavigation).Include(t => t.IdEditorialNavigation);
            return View(await dBBiblioteca_ProyectoFinalContext.ToListAsync());
        }

        // GET: TLibroes/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var tLibro = await _context.TLibros
                .Include(t => t.IdAutorNavigation)
                .Include(t => t.IdCategoriaNavigation)
                .Include(t => t.IdEditorialNavigation)
                .FirstOrDefaultAsync(m => m.IdLibro == id);
            if (tLibro == null)
            {
                return NotFound();
            }

            return View(tLibro);
        }

        // GET: TLibroes/Create
        public IActionResult Create()
        {
            ViewData["IdAutor"] = new SelectList(_context.TAutors, "IdAutor", "NombreApellidos");
            ViewData["IdCategoria"] = new SelectList(_context.TCategoriaLibros, "IdCategoria", "Nombre");
            ViewData["IdEditorial"] = new SelectList(_context.TEditorials, "IdEditorial", "Nombre");
            return View();
        }

        // POST: TLibroes/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("IdLibro,Titulo,Isbn,UrlImagen,IdAutor,IdCategoria,IdEditorial,Ubicacion,Ejemplares,EjemplaresDisponibles,Estado,FechaCreacion")] TLibro tLibro)
        {
            if (ModelState.IsValid)
            {
                _context.Add(tLibro);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["IdAutor"] = new SelectList(_context.TAutors, "IdAutor", "NombreApellidos", tLibro.IdAutor);
            ViewData["IdCategoria"] = new SelectList(_context.TCategoriaLibros, "IdCategoria", "Nombre", tLibro.IdCategoria);
            ViewData["IdEditorial"] = new SelectList(_context.TEditorials, "IdEditorial", "Nombre", tLibro.IdEditorial);
            return View(tLibro);
        }

        // GET: TLibroes/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var tLibro = await _context.TLibros.FindAsync(id);
            if (tLibro == null)
            {
                return NotFound();
            }
            ViewData["IdAutor"] = new SelectList(_context.TAutors, "IdAutor", "NombreApellidos", tLibro.IdAutor);
            ViewData["IdCategoria"] = new SelectList(_context.TCategoriaLibros, "IdCategoria", "Nombre", tLibro.IdCategoria);
            ViewData["IdEditorial"] = new SelectList(_context.TEditorials, "IdEditorial", "Nombre", tLibro.IdEditorial);
            return View(tLibro);
        }

        // POST: TLibroes/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("IdLibro,Titulo,Isbn,UrlImagen,IdAutor,IdCategoria,IdEditorial,Ubicacion,Ejemplares,EjemplaresDisponibles,Estado,FechaCreacion")] TLibro tLibro)
        {
            if (id != tLibro.IdLibro)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(tLibro);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!TLibroExists(tLibro.IdLibro))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["IdAutor"] = new SelectList(_context.TAutors, "IdAutor", "NombreApellidos", tLibro.IdAutor);
            ViewData["IdCategoria"] = new SelectList(_context.TCategoriaLibros, "IdCategoria", "Nombre", tLibro.IdCategoria);
            ViewData["IdEditorial"] = new SelectList(_context.TEditorials, "IdEditorial", "Nombre", tLibro.IdEditorial);
            return View(tLibro);
        }

        // GET: TLibroes/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var tLibro = await _context.TLibros
                .Include(t => t.IdAutorNavigation)
                .Include(t => t.IdCategoriaNavigation)
                .Include(t => t.IdEditorialNavigation)
                .FirstOrDefaultAsync(m => m.IdLibro == id);
            if (tLibro == null)
            {
                return NotFound();
            }

            return View(tLibro);
        }

        // POST: TLibroes/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var tLibro = await _context.TLibros.FindAsync(id);
            _context.TLibros.Remove(tLibro);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool TLibroExists(int id)
        {
            return _context.TLibros.Any(e => e.IdLibro == id);
        }
    }
}
