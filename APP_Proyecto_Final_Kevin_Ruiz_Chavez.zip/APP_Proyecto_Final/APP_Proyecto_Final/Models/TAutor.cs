﻿using System;
using System.Collections.Generic;

#nullable disable

namespace APP_Proyecto_Final.Models
{
    public partial class TAutor
    {
        public TAutor()
        {
            TLibros = new HashSet<TLibro>();
        }

        public int IdAutor { get; set; }
        public string NombreApellidos { get; set; }
        public bool Estado { get; set; }
        public DateTime? FechaCreacion { get; set; }

        public virtual ICollection<TLibro> TLibros { get; set; }
    }
}
