﻿using System;
using System.Collections.Generic;

#nullable disable

namespace APP_Proyecto_Final.Models
{
    public partial class TCategoriaLibro
    {
        public TCategoriaLibro()
        {
            TLibros = new HashSet<TLibro>();
        }

        public int IdCategoria { get; set; }
        public string Nombre { get; set; }
        public bool Estado { get; set; }
        public DateTime? FechaCreacion { get; set; }

        public virtual ICollection<TLibro> TLibros { get; set; }
    }
}
