﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

#nullable disable

namespace APP_Proyecto_Final.Models
{
    public partial class DBBiblioteca_ProyectoFinalContext : DbContext
    {
        public DBBiblioteca_ProyectoFinalContext()
        {
        }

        public DBBiblioteca_ProyectoFinalContext(DbContextOptions<DBBiblioteca_ProyectoFinalContext> options)
            : base(options)
        {
        }

        public virtual DbSet<TAutor> TAutors { get; set; }
        public virtual DbSet<TCategoriaLibro> TCategoriaLibros { get; set; }
        public virtual DbSet<TEditorial> TEditorials { get; set; }
        public virtual DbSet<TEstadoPrestamo> TEstadoPrestamos { get; set; }
        public virtual DbSet<TLibro> TLibros { get; set; }
        public virtual DbSet<TPrestamo> TPrestamos { get; set; }
        public virtual DbSet<TTipopersona> TTipopersonas { get; set; }
        public virtual DbSet<TUsuario> TUsuarios { get; set; }

        

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("Relational:Collation", "Modern_Spanish_CI_AS");

            modelBuilder.Entity<TAutor>(entity =>
            {
                entity.HasKey(e => e.IdAutor)
                    .HasName("PK_Autor");

                entity.ToTable("T_AUTOR");

                entity.Property(e => e.IdAutor).HasColumnName("ID_Autor");

                entity.Property(e => e.FechaCreacion)
                    .HasColumnType("datetime")
                    .HasColumnName("Fecha_creacion");

                entity.Property(e => e.NombreApellidos)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TCategoriaLibro>(entity =>
            {
                entity.HasKey(e => e.IdCategoria)
                    .HasName("PK_Categoria");

                entity.ToTable("T_CATEGORIA_LIBRO");

                entity.Property(e => e.IdCategoria).HasColumnName("ID_Categoria");

                entity.Property(e => e.FechaCreacion)
                    .HasColumnType("datetime")
                    .HasColumnName("Fecha_creacion");

                entity.Property(e => e.Nombre)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TEditorial>(entity =>
            {
                entity.HasKey(e => e.IdEditorial)
                    .HasName("PK_Editorial");

                entity.ToTable("T_EDITORIAL");

                entity.Property(e => e.IdEditorial).HasColumnName("ID_Editorial");

                entity.Property(e => e.Correo)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.FechaCreacion)
                    .HasColumnType("datetime")
                    .HasColumnName("Fecha_creacion");

                entity.Property(e => e.Nombre)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Pais)
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TEstadoPrestamo>(entity =>
            {
                entity.HasKey(e => e.IdEstado)
                    .HasName("PK_EstadoPrestamo");

                entity.ToTable("T_ESTADO_PRESTAMO");

                entity.Property(e => e.IdEstado).HasColumnName("ID_Estado");

                entity.Property(e => e.Descripcion)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.FechaCreacion)
                    .HasColumnType("datetime")
                    .HasColumnName("Fecha_creacion");
            });

            modelBuilder.Entity<TLibro>(entity =>
            {
                entity.HasKey(e => e.IdLibro)
                    .HasName("PK_Libro");

                entity.ToTable("T_Libro");

                entity.Property(e => e.IdLibro).HasColumnName("ID_Libro");

                entity.Property(e => e.EjemplaresDisponibles).HasColumnName("Ejemplares_Disponibles");

                entity.Property(e => e.FechaCreacion)
                    .HasColumnType("datetime")
                    .HasColumnName("Fecha_creacion");

                entity.Property(e => e.IdAutor).HasColumnName("Id_Autor");

                entity.Property(e => e.IdCategoria).HasColumnName("Id_Categoria");

                entity.Property(e => e.IdEditorial).HasColumnName("Id_Editorial");

                entity.Property(e => e.Isbn)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("ISBN");

                entity.Property(e => e.Titulo)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Ubicacion)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.UrlImagen)
                    .HasMaxLength(200)
                    .IsUnicode(false)
                    .HasColumnName("URL_Imagen");

                entity.HasOne(d => d.IdAutorNavigation)
                    .WithMany(p => p.TLibros)
                    .HasForeignKey(d => d.IdAutor)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_T_Libro_T_AUTOR");

                entity.HasOne(d => d.IdCategoriaNavigation)
                    .WithMany(p => p.TLibros)
                    .HasForeignKey(d => d.IdCategoria)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_T_Libro_T_CATEGORIA_LIBRO");

                entity.HasOne(d => d.IdEditorialNavigation)
                    .WithMany(p => p.TLibros)
                    .HasForeignKey(d => d.IdEditorial)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_T_Libro_T_EDITORIAL");
            });

            modelBuilder.Entity<TPrestamo>(entity =>
            {
                entity.HasKey(e => e.IdPrestamo)
                    .HasName("PK_Prestamo");

                entity.ToTable("T_PRESTAMO");

                entity.Property(e => e.IdPrestamo).HasColumnName("ID_Prestamo");

                entity.Property(e => e.EstadoEntrega)
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("Estado_Entrega");

                entity.Property(e => e.EstadoRecibido)
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("Estado_Recibido");

                entity.Property(e => e.FechaCreacion)
                    .HasColumnType("datetime")
                    .HasColumnName("Fecha_creacion");

                entity.Property(e => e.FechaDevolucion)
                    .HasColumnType("datetime")
                    .HasColumnName("Fecha_Devolucion");

                entity.Property(e => e.FechaDevolucionReal)
                    .HasColumnType("datetime")
                    .HasColumnName("Fecha_Devolucion_Real");

                entity.Property(e => e.IdEstadoPrestamo).HasColumnName("ID_Estado_Prestamo");

                entity.Property(e => e.IdLibro).HasColumnName("ID_Libro");

                entity.Property(e => e.IdPersona).HasColumnName("ID_Persona");

                entity.HasOne(d => d.IdEstadoPrestamoNavigation)
                    .WithMany(p => p.TPrestamos)
                    .HasForeignKey(d => d.IdEstadoPrestamo)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_T_PRESTAMO_T_ESTADO_PRESTAMO");

                entity.HasOne(d => d.IdLibroNavigation)
                    .WithMany(p => p.TPrestamos)
                    .HasForeignKey(d => d.IdLibro)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_T_PRESTAMO_T_Libro");

                entity.HasOne(d => d.IdPersonaNavigation)
                    .WithMany(p => p.TPrestamos)
                    .HasForeignKey(d => d.IdPersona)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_T_PRESTAMO_T_USUARIOS");
            });

            modelBuilder.Entity<TTipopersona>(entity =>
            {
                entity.HasKey(e => e.IdTipoPersona)
                    .HasName("PK_TipoPersona");

                entity.ToTable("T_TIPOPERSONA");

                entity.Property(e => e.IdTipoPersona).HasColumnName("ID_TipoPersona");

                entity.Property(e => e.Descripcion)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.FechaCreacion)
                    .HasColumnType("datetime")
                    .HasColumnName("Fecha_creacion");
            });

            modelBuilder.Entity<TUsuario>(entity =>
            {
                entity.HasKey(e => e.IdPersona)
                    .HasName("PK_Usuarios");

                entity.ToTable("T_USUARIOS");

                entity.Property(e => e.IdPersona).HasColumnName("ID_persona");

                entity.Property(e => e.Apellidos)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Clave)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Codigo)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.Correo)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.FechaCreacion)
                    .HasColumnType("datetime")
                    .HasColumnName("Fecha_creacion");

                entity.Property(e => e.IdTipopersona).HasColumnName("Id_Tipopersona");

                entity.Property(e => e.Nombre)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.HasOne(d => d.IdTipopersonaNavigation)
                    .WithMany(p => p.TUsuarios)
                    .HasForeignKey(d => d.IdTipopersona)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_T_USUARIOS_T_TIPOPERSONA");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
