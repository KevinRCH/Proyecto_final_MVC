﻿using System;
using System.Collections.Generic;

#nullable disable

namespace APP_Proyecto_Final.Models
{
    public partial class TPrestamo
    {
        public int IdPrestamo { get; set; }
        public int IdEstadoPrestamo { get; set; }
        public int IdPersona { get; set; }
        public int IdLibro { get; set; }
        public DateTime? FechaDevolucion { get; set; }
        public DateTime FechaDevolucionReal { get; set; }
        public string EstadoEntrega { get; set; }
        public string EstadoRecibido { get; set; }
        public bool Estado { get; set; }
        public DateTime? FechaCreacion { get; set; }

        public virtual TEstadoPrestamo IdEstadoPrestamoNavigation { get; set; }
        public virtual TLibro IdLibroNavigation { get; set; }
        public virtual TUsuario IdPersonaNavigation { get; set; }

    }
}
