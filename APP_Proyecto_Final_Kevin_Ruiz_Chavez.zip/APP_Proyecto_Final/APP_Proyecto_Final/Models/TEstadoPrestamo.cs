﻿using System;
using System.Collections.Generic;

#nullable disable

namespace APP_Proyecto_Final.Models
{
    public partial class TEstadoPrestamo
    {
        public TEstadoPrestamo()
        {
            TPrestamos = new HashSet<TPrestamo>();
        }

        public int IdEstado { get; set; }
        public string Descripcion { get; set; }
        public bool Estado { get; set; }
        public DateTime? FechaCreacion { get; set; }

        public virtual ICollection<TPrestamo> TPrestamos { get; set; }
    }
}
