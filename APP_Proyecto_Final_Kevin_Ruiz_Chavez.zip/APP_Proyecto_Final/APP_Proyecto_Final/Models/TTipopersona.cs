﻿using System;
using System.Collections.Generic;

#nullable disable

namespace APP_Proyecto_Final.Models
{
    public partial class TTipopersona
    {
        public TTipopersona()
        {
            TUsuarios = new HashSet<TUsuario>();
        }

        public int IdTipoPersona { get; set; }
        public string Descripcion { get; set; }
        public bool Estado { get; set; }
        public DateTime? FechaCreacion { get; set; }

        public virtual ICollection<TUsuario> TUsuarios { get; set; }
    }
}
