﻿using System;
using System.Collections.Generic;

#nullable disable

namespace APP_Proyecto_Final.Models
{
    public partial class TEditorial
    {
        public TEditorial()
        {
            TLibros = new HashSet<TLibro>();
        }

        public int IdEditorial { get; set; }
        public string Nombre { get; set; }
        public string Correo { get; set; }
        public string Pais { get; set; }
        public bool Estado { get; set; }
        public DateTime? FechaCreacion { get; set; }

        public virtual ICollection<TLibro> TLibros { get; set; }
    }
}
