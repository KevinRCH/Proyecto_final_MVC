﻿using System;
using System.Collections.Generic;

#nullable disable

namespace APP_Proyecto_Final.Models
{
    public partial class TLibro
    {
        public TLibro()
        {
            TPrestamos = new HashSet<TPrestamo>();
        }

        public int IdLibro { get; set; }
        public string Titulo { get; set; }
        public string Isbn { get; set; }
        public string UrlImagen { get; set; }
        public int IdAutor { get; set; }
        public int IdCategoria { get; set; }
        public int IdEditorial { get; set; }
        public string Ubicacion { get; set; }
        public int Ejemplares { get; set; }
        public int? EjemplaresDisponibles { get; set; }
        public bool Estado { get; set; }
        public DateTime? FechaCreacion { get; set; }

        public virtual TAutor IdAutorNavigation { get; set; }
        public virtual TCategoriaLibro IdCategoriaNavigation { get; set; }
        public virtual TEditorial IdEditorialNavigation { get; set; }
        public virtual ICollection<TPrestamo> TPrestamos { get; set; }
    }
}
