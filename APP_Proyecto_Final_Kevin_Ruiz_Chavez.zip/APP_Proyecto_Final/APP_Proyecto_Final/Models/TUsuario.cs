﻿using System;
using System.Collections.Generic;

#nullable disable

namespace APP_Proyecto_Final.Models
{
    public partial class TUsuario
    {
        public TUsuario()
        {
            TPrestamos = new HashSet<TPrestamo>();
        }

        public int IdPersona { get; set; }
        public string Nombre { get; set; }
        public string Apellidos { get; set; }
        public string Correo { get; set; }
        public string Clave { get; set; }
        public string Codigo { get; set; }
        public int IdTipopersona { get; set; }
        public bool Estado { get; set; }
        public DateTime? FechaCreacion { get; set; }

        public virtual TTipopersona IdTipopersonaNavigation { get; set; }
        public virtual ICollection<TPrestamo> TPrestamos { get; set; }
    }
}
